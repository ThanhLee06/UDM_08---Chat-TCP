# UDM_08 Chat TCP – ST-124 → ST-129

Maven project Java 21 + JavaFX cho ứng dụng Chat TCP Client–Server.

## Chức năng đã hoàn thiện

- **ST-124:** Server giữ kho hội thoại và trả danh sách hội thoại để khôi phục Sidebar sau khi Client đăng nhập.
- **ST-125:** Cập nhật tin cuối, thời gian hoạt động và sắp xếp hội thoại mới nhất lên đầu.
- **ST-126:** Chọn hội thoại và tải lịch sử chat từ Server.
- **ST-127:** Tạo/chọn cuộc trò chuyện riêng từ danh sách người dùng online.
- **ST-128:** Tìm kiếm hội thoại trong Sidebar theo username hoặc tin nhắn cuối.
- **ST-129:** Hoàn thiện đăng nhập, kiểm tra Username/Host/Port phía Client và xử lý lỗi/phản hồi từ Server.

## Chạy bằng IntelliJ IDEA

1. Mở **thư mục `Code`** bằng IntelliJ IDEA.
2. Chọn **JDK 21**.
3. IntelliJ nhận diện `pom.xml` → chọn **Reload Maven Project**.
4. Chạy `vn.edu.ut.udm08.server.core.ServerApplication` trước.
5. Chạy `vn.edu.ut.udm08.client.app.LoginApplication`.
6. Client mặc định dùng `127.0.0.1:8080`.
7. Mở hai Client với hai username khác nhau để thử chat riêng.

## Thứ tự kiểm tra chức năng

- Client A đăng nhập → Sidebar được nhận từ Server.
- Client B đăng nhập → danh sách online được đồng bộ.
- A chọn B → Server trả lịch sử hội thoại.
- A gửi tin → B nhận tin, A nhận `CHAT_OK`, sau đó cả hai nhận Sidebar cập nhật.
- Chọn lại hội thoại → lịch sử vẫn còn trong bộ nhớ của Server cho tới khi Server dừng.
- Nhập từ khóa vào ô tìm kiếm → Sidebar lọc theo username/tin cuối.

> Lưu ý: `ConversationStore` hiện lưu trong bộ nhớ (in-memory). Khi **Server tắt/restart**, lịch sử sẽ được tạo lại từ đầu. Đây là thiết kế phù hợp với phạm vi Chat TCP hiện tại; nếu đề bài yêu cầu lưu lâu dài sau restart thì cần thêm database/file persistence.
