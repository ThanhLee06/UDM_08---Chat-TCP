package vn.edu.ut.udm08.client.network;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.util.UUID;

import vn.edu.ut.udm08.shared.model.MessageType;
import vn.edu.ut.udm08.shared.model.ProtocolMessage;
import vn.edu.ut.udm08.shared.protocol.JsonUtil;

/**
 * Lớp ChatClient quản lý kết nối TCP đến Server và gửi/nhận thông điệp.
 */
public class ChatClient {
    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;
    private ChatReceiver receiver;
    
    private String username;
    private String avatarId;

    /**
     * Kết nối đến TCP Server, thiết lập luồng đọc ngầm nhận tin nhắn và gửi gói tin chào hỏi (HELLO).
     *
     * @param host Địa chỉ IP hoặc tên miền của Server.
     * @param port Cổng dịch vụ của Server.
     * @param username Tên người dùng kết nối.
     * @param avatarId ID ảnh đại diện người dùng chọn.
     * @param listener Callback để chuyển tiếp sự kiện mạng lên giao diện.
     * @throws IOException Nếu xảy ra lỗi kết nối mạng hoặc lỗi định dạng JSON.
     * @throws IllegalArgumentException Nếu host hoặc port không hợp lệ.
     */
    public void connect(String host, int port, String username, String avatarId, ChatListener listener) throws IOException {
        connect(new ClientConfig(host, port), username, avatarId, listener);
    }

    /**
     * Kết nối đến TCP Server dựa trên cấu hình ClientConfig.
     *
     * @param config Cấu hình kết nối chứa Host và Port hợp lệ.
     * @param username Tên người dùng kết nối.
     * @param avatarId ID ảnh đại diện người dùng chọn.
     * @param listener Callback để chuyển tiếp sự kiện mạng lên giao diện.
     * @throws IOException Nếu xảy ra lỗi kết nối mạng hoặc lỗi định dạng JSON.
     * @throws IllegalArgumentException Nếu config là null.
     */
    public void connect(ClientConfig config, String username, String avatarId, ChatListener listener) throws IOException {
        if (isConnected()) {
            throw new IllegalStateException("ChatClient đã được kết nối trước đó");
        }
        if (config == null) {
            throw new IllegalArgumentException("ClientConfig không được để null");
        }
        if (username == null || username.isBlank()) {
            throw new IllegalArgumentException("Username không được để trống");
        }
        if (avatarId == null || avatarId.isBlank()) {
            throw new IllegalArgumentException("AvatarId không được để trống");
        }

        // 1. Thiết lập kết nối Socket TCP
        this.socket = new Socket(config.getHost(), config.getPort());
        
        // 2. Khởi tạo các luồng đọc/ghi dữ liệu sử dụng UTF-8
        this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        this.writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
        
        this.username = username.trim();
        this.avatarId = avatarId.trim();

        // 3. Khởi chạy luồng nhận tin nhắn chạy ngầm (bọc JavaFX wrapper để an toàn luồng)
// Các callback từ ChatReceiver chạy trên background thread; wrapper đưa chúng về JavaFX thread.
        ChatListener safeListener = listener == null ? null : new JavaFXChatListenerWrapper(listener);

        this.receiver = new ChatReceiver(this, reader, safeListener);
        Thread receiverThread = new Thread(this.receiver, "ChatReceiverThread");
        receiverThread.setDaemon(true); // Đảm bảo thread tự tắt khi app JavaFX chính dừng
        receiverThread.start();

        // 4. Đóng gói gói tin chào hỏi HELLO
        ProtocolMessage helloMessage = new ProtocolMessage(MessageType.HELLO);
        helloMessage.sender = username;
        helloMessage.avatarId = avatarId;
        helloMessage.timestamp = System.currentTimeMillis();

        // 5. Chuyển đổi gói tin sang dạng JSON
        String json = JsonUtil.toJson(helloMessage);

        // 6. Gửi gói tin JSON qua luồng TCP tới Server
        sendRawMessage(json);
    }

    /**
     * Gửi chuỗi tin nhắn thô qua luồng TCP đến Server.
     *
     * @param rawMessage Chuỗi tin nhắn (thường là định dạng JSON).
     */
    public void sendRawMessage(String rawMessage) {
        if (writer != null) {
            writer.println(rawMessage);
        }
    }

    /**
     * Đóng gói và gửi gói tin CHAT đến một đối tượng nhận (target).
     *
     * @param target Tên người nhận tin nhắn (username nhận tin hoặc tên phòng/kênh).
     * @param content Nội dung tin nhắn cần gửi (tối đa 5000 ký tự).
     * @throws IOException Nếu kết nối bị ngắt hoặc xảy ra lỗi luồng ghi.
     * @throws IllegalArgumentException Nếu target hoặc content rỗng, hoặc content vượt quá 5000 ký tự.
     */
    /** Yêu cầu Server gửi lại Sidebar hội thoại. */
    public void requestConversations() throws IOException {
        ensureConnected();
        ProtocolMessage request = new ProtocolMessage(MessageType.CONVERSATION_LIST);
        request.sender = username;
        request.timestamp = System.currentTimeMillis();
        sendRawMessage(JsonUtil.toJson(request));
    }

    /** Yêu cầu lịch sử của một cuộc trò chuyện riêng. */
    public void requestConversationHistory(String target) throws IOException {
        ensureConnected();
        if (target == null || target.isBlank()) {
            throw new IllegalArgumentException("Target không được để trống");
        }
        ProtocolMessage request = new ProtocolMessage(MessageType.CONVERSATION_HISTORY);
        request.sender = username;
        request.target = target.trim();
        request.timestamp = System.currentTimeMillis();
        sendRawMessage(JsonUtil.toJson(request));
    }

    /** Tìm kiếm hội thoại đã có trên Server. */
    public void searchConversations(String query) throws IOException {
        ensureConnected();
        ProtocolMessage request = new ProtocolMessage(MessageType.CONVERSATION_SEARCH);
        request.sender = username;
        request.content = query == null ? "" : query.trim();
        request.timestamp = System.currentTimeMillis();
        sendRawMessage(JsonUtil.toJson(request));
    }

    private void ensureConnected() throws IOException {
        if (!isConnected()) {
            throw new IOException("Chưa kết nối đến Server");
        }
    }

    public void sendMessage(String target, String content) throws IOException {
        if (!isConnected()) {
            throw new IOException("Không thể gửi tin nhắn: Chưa kết nối đến Server hoặc kết nối đã bị đóng.");
        }
        if (target == null || target.isBlank()) {
            throw new IllegalArgumentException("Người nhận (target) không được để trống");
        }
        if (content == null || content.isBlank()) {
            throw new IllegalArgumentException("Nội dung tin nhắn không được để trống");
        }

        ProtocolMessage chatMessage = new ProtocolMessage(MessageType.CHAT);
        chatMessage.messageId = UUID.randomUUID().toString();
        chatMessage.sender = this.username;
        chatMessage.target = target.trim();
        chatMessage.content = content.trim();
        chatMessage.timestamp = System.currentTimeMillis();
        sendMessage(chatMessage);
    }

    /** Gửi đúng ProtocolMessage đã được Controller tạo, giữ nguyên messageId/timestamp. */
    public void sendMessage(ProtocolMessage chatMessage) throws IOException {
        if (!isConnected()) {
            throw new IOException("Không thể gửi tin nhắn: Chưa kết nối đến Server hoặc kết nối đã bị đóng.");
        }
        if (chatMessage == null || chatMessage.type != MessageType.CHAT) {
            throw new IllegalArgumentException("Gói tin phải có type CHAT");
        }
        if (chatMessage.target == null || chatMessage.target.isBlank()) {
            throw new IllegalArgumentException("Người nhận (target) không được để trống");
        }
        if (chatMessage.content == null || chatMessage.content.isBlank()) {
            throw new IllegalArgumentException("Nội dung tin nhắn không được để trống");
        }
        if (chatMessage.content.length() > 5000) {
            throw new IllegalArgumentException("Nội dung tin nhắn quá dài (tối đa 5000 ký tự)");
        }

        chatMessage.sender = this.username;
        chatMessage.target = chatMessage.target.trim();
        chatMessage.content = chatMessage.content.trim();
        if (chatMessage.messageId == null || chatMessage.messageId.isBlank()) {
            chatMessage.messageId = UUID.randomUUID().toString();
        }
        if (chatMessage.timestamp == null || chatMessage.timestamp <= 0) {
            chatMessage.timestamp = System.currentTimeMillis();
        }

        sendRawMessage(JsonUtil.toJson(chatMessage));
        if (writer != null && writer.checkError()) {
            throw new IOException("Không thể gửi tin nhắn: Gặp lỗi trên TCP Socket.");
        }
    }

    /**
     * Ngắt kết nối TCP và đóng toàn bộ luồng dữ liệu an toàn (Idempotent).
     */
    public synchronized void disconnect() {
        try {
            // Gửi gói tin thông báo ngắt kết nối (DISCONNECT) trước khi đóng socket
            if (writer != null && socket != null && !socket.isClosed()) {
                ProtocolMessage disconnectMessage = new ProtocolMessage(MessageType.DISCONNECT);
                disconnectMessage.sender = this.username;
                disconnectMessage.timestamp = System.currentTimeMillis();
                try {
                    String json = JsonUtil.toJson(disconnectMessage);
                    writer.println(json);
                } catch (Exception ignored) {
                    // Bỏ qua lỗi JSON khi đang đóng kết nối
                }
            }
        } finally {
            // Đảm bảo đóng tất cả tài nguyên và đặt lại trạng thái dù có lỗi xảy ra
            closeResources();
        }
    }

    /**
     * Đóng an toàn các luồng dữ liệu, socket và đặt lại trạng thái client.
     */
    private void closeResources() {
        // 1. Dừng cờ luồng đọc ngầm trước
        if (receiver != null) {
            receiver.stop();
            receiver = null;
        }

        // 2. Đóng Socket trước để ngắt ngay lập tức mọi thao tác đọc/ghi đang chờ (blocking I/O)
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException ignored) {
        } finally {
            socket = null;
        }

        // 3. Đóng luồng đọc
        try {
            if (reader != null) {
                reader.close();
            }
        } catch (IOException ignored) {
        } finally {
            reader = null;
        }

        // 4. Đóng luồng ghi
        if (writer != null) {
            writer.close();
            writer = null;
        }

        // 5. Đặt lại thông tin người dùng để sẵn sàng cho lần kết nối sau
        this.username = null;
        this.avatarId = null;
    }

    /**
     * Kiểm tra trạng thái kết nối của Client.
     *
     * @return true nếu kết nối vẫn đang mở, ngược lại false.
     */
    public boolean isConnected() {
        return socket != null && !socket.isClosed();
    }

    public String getUsername() {
        return username;
    }

    public String getAvatarId() {
        return avatarId;
    }
}
