package vn.edu.ut.udm08.client.network;

import java.util.List;
import vn.edu.ut.udm08.shared.model.ConversationSummary;
import vn.edu.ut.udm08.shared.model.ProtocolMessage;
import vn.edu.ut.udm08.shared.model.UserProfile;

public interface ChatListener {
    void onLoginSuccess(ProtocolMessage message);
    void onUserListUpdated(List<UserProfile> users);
    void onMessageReceived(ProtocolMessage message);
    void onMessageSentSuccess(String messageId);
    void onErrorReceived(String errorCode, String errorMessage);
    void onConnectionLost(Throwable cause);

    /** Server gửi Sidebar/hội thoại sau khi đăng nhập hoặc khi có tin mới. */
    default void onConversationListUpdated(List<ConversationSummary> conversations) {}

    /** Server trả lịch sử của cuộc trò chuyện đang chọn. */
    default void onConversationHistory(String target, List<ProtocolMessage> history) {}
}
