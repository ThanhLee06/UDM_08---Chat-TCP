package vn.edu.ut.udm08.server.core;

/** Điểm khởi động Server TCP độc lập. */
public final class ServerApplication {
    private ServerApplication() {}

    public static void main(String[] args) {
        try {
            ServerConfig config = ServerConfig.load();
            ChatServer server = new ChatServer(config);
            Runtime.getRuntime().addShutdownHook(new Thread(server::stop, "ChatServer-shutdown"));
            System.out.println("Server TCP đang lắng nghe trên cổng: " + config.getPort());
            server.start();
        } catch (Exception e) {
            System.err.println("Không thể khởi động Server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
