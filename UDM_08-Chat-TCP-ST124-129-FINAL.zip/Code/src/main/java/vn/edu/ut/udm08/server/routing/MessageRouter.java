package vn.edu.ut.udm08.server.routing;

import vn.edu.ut.udm08.server.session.ClientSession;
import vn.edu.ut.udm08.server.session.OnlineUserRegistry;
import vn.edu.ut.udm08.server.conversation.ConversationStore;
import vn.edu.ut.udm08.shared.model.ConversationSummary;
import vn.edu.ut.udm08.shared.model.MessageType;
import vn.edu.ut.udm08.shared.model.ProtocolMessage;

// Lop dinh tuyen tin nhan giua Client va Server
public class MessageRouter {
    private final OnlineUserRegistry registry;
    private final ConversationStore conversationStore;

    public MessageRouter(OnlineUserRegistry registry) {
        this(registry, new ConversationStore());
    }

    public MessageRouter(OnlineUserRegistry registry, ConversationStore conversationStore) {
        if(registry == null){
            throw new IllegalArgumentException("Registry must not be null!");
        }
        this.registry = registry;
        if (conversationStore == null) {
            throw new IllegalArgumentException("ConversationStore must not be null!");
        }
        this.conversationStore = conversationStore;
    }

    // Xu ly dinh tuyen tin nhan CHAT rieng tu nguoi gui den nguoi nhan
    public void handleChatMessage(ClientSession senderSession, ProtocolMessage msg) {
        try {
            // 1. Kiem tra phien lam viec nguoi gui
            if (senderSession == null || senderSession.getUsername() == null) {
                sendErrorMessage(senderSession, msg != null ? msg.messageId : null, "UNAUTHORIZED", "Chua dang nhap");
                return;
            }

            // 2. Kiem tra nguoi gui (sender) co khop voi session hien tai hay khong
            if (msg.sender == null || !msg.sender.equals(senderSession.getUsername())) {
                sendErrorMessage(senderSession, msg.messageId, "INVALID_SENDER", "Nguoi gui khong khop voi phien lam viec");
                return;
            }

            // 3. Kiem tra nguoi nhan (target) co bi rong khong
            if (msg.target == null || msg.target.trim().isEmpty()) {
                sendErrorMessage(senderSession, msg.messageId, "INVALID_TARGET", "Nguoi nhan khong duoc de trong");
                return;
            }

            // 4. Kiem tra noi dung tin nhan (content) khong duoc rong hoac qua dai (> 5000 ky tu)
            if (msg.content == null || msg.content.trim().isEmpty()) {
                sendErrorMessage(senderSession, msg.messageId, "INVALID_CONTENT", "Noi dung tin nhan khong duoc de trong");
                return;
            }
            if (msg.content.length() > 5000) {
                sendErrorMessage(senderSession, msg.messageId, "CONTENT_TOO_LONG", "Noi dung tin nhan qua dai (toi da 5000 ky tu)");
                return;
            }

            // 5. Tim ClientSession cua nguoi nhan trong OnlineUserRegistry
            ClientSession targetSession = registry.find(msg.target);
            if (targetSession == null || !targetSession.isConnected()) {
                // Nguoi nhan khong ton tai hoac da offline
                sendErrorMessage(senderSession, msg.messageId, "USER_OFFLINE", "Nguoi nhan khong ton tai hoac da offline");
                return;
            }

            // 6. Chuan hoa metadata truoc khi luu/giao tin nhan.
            // Client thuong da gan timestamp, nhung Server van phai tu bo sung khi
            // nhan duoc goi tin cu/thieu timestamp de tranh NullPointerException.
            if (msg.timestamp == null || msg.timestamp <= 0) {
                msg.timestamp = System.currentTimeMillis();
            }
            if (msg.messageId == null || msg.messageId.isBlank()) {
                msg.messageId = java.util.UUID.randomUUID().toString();
            }
            msg.target = msg.target.trim();
            msg.content = msg.content.trim();

            // 7. Luu tin nhan vao kho hoi thoai truoc khi phat cho client.
            conversationStore.append(msg, senderSession.getAvatarId(), targetSession.getAvatarId());

            // 8. Chuyen tiep nguyen ven goi tin CHAT sang nguoi nhan.
            try {
                targetSession.sendMessage(msg);
            } catch (Exception e) {
                sendErrorMessage(senderSession, msg.messageId, "DELIVERY_FAILED", "Khong the gui tin nhan toi nguoi nhan");
                return;
            }

            // 9. Phan hoi CHAT_OK truoc khi gui CONVERSATION_LIST.
            // Thu tu nay giu tuong thich voi giao thuc cu: Client gui CHAT se nhan
            // CHAT_OK truoc, sau do moi nhan goi cap nhat Sidebar.
            ProtocolMessage okMsg = new ProtocolMessage(MessageType.CHAT_OK);
            okMsg.messageId = msg.messageId;
            okMsg.sender = "SERVER";
            okMsg.target = msg.sender;
            okMsg.timestamp = System.currentTimeMillis();

            senderSession.sendMessage(okMsg);

            // 10. Dong bo Sidebar cho ca hai dau cuoc tro chuyen sau khi CHAT_OK da
            // duoc gui thanh cong. Neu mot client khong con ket noi thi bo qua an toan.
            sendConversationList(senderSession);
            sendConversationList(targetSession);

        } catch (Exception e) {
            // Try-catch an toan: bat moi loi de khong lam sap server
            System.err.println("Loi dinh tuyen tin nhan: " + e.getMessage());
            sendErrorMessage(senderSession, msg != null ? msg.messageId : null, "ERROR", "Loi he thong dinh tuyen");
        }
    }

    public void handleConversationRequest(ClientSession session, ProtocolMessage msg) {
        if (session == null || session.getUsername() == null) {
            sendErrorMessage(session, null, "UNAUTHORIZED", "Chua dang nhap");
            return;
        }
        if (msg == null || msg.type == null) return;

        switch (msg.type) {
            case CONVERSATION_LIST -> sendConversationList(session);
            case CONVERSATION_HISTORY -> {
                if (msg.target == null || msg.target.isBlank()) {
                    sendErrorMessage(session, null, "INVALID_TARGET", "Nguoi dung can tai lich su khong hop le");
                    return;
                }
                ProtocolMessage response = new ProtocolMessage(MessageType.CONVERSATION_HISTORY);
                response.sender = "SERVER";
                response.target = msg.target.trim();
                response.timestamp = System.currentTimeMillis();
                response.history = conversationStore.getHistory(session.getUsername(), response.target);
                safeSend(session, response);
            }
            case CONVERSATION_SEARCH -> {
                ProtocolMessage response = new ProtocolMessage(MessageType.CONVERSATION_LIST);
                response.sender = "SERVER";
                response.timestamp = System.currentTimeMillis();
                response.content = msg.content == null ? "" : msg.content;
                response.conversations = conversationStore.search(session.getUsername(), msg.content);
                safeSend(session, response);
            }
            default -> { }
        }
    }

    public void sendConversationList(ClientSession session) {
        if (session == null || session.getUsername() == null) return;
        ProtocolMessage response = new ProtocolMessage(MessageType.CONVERSATION_LIST);
        response.sender = "SERVER";
        response.target = session.getUsername();
        response.timestamp = System.currentTimeMillis();
        response.conversations = conversationStore.getConversationsFor(session.getUsername());
        safeSend(session, response);
    }

    private void safeSend(ClientSession session, ProtocolMessage message) {
        try {
            session.sendMessage(message);
        } catch (Exception ignored) {
        }
    }

    // Ham phu ho tro gui goi tin ERROR ve cho client
    private void sendErrorMessage(ClientSession session, String messageId, String errorCode, String errorMessage) {
        if (session == null) {
            return;
        }
        try {
            ProtocolMessage err = new ProtocolMessage(MessageType.ERROR);
            err.messageId = messageId;
            err.sender = "SERVER";
            err.errorCode = errorCode;
            err.errorMessage = errorMessage;
            err.timestamp = System.currentTimeMillis();
            session.sendMessage(err);
        } catch (Exception ignored) {
            // Bo qua neu khong gui duoc loi
        }
    }
}
