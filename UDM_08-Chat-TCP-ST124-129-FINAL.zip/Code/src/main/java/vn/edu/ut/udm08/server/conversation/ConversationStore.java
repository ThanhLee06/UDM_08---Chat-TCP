package vn.edu.ut.udm08.server.conversation;

import vn.edu.ut.udm08.shared.model.ConversationSummary;
import vn.edu.ut.udm08.shared.model.ProtocolMessage;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Kho hội thoại phía Server. Dữ liệu sống trong bộ nhớ của Server để phục vụ
 * Sidebar, đồng bộ tin cuối cùng và tải lịch sử khi client đăng nhập lại.
 */
public class ConversationStore {
    private static final int MAX_MESSAGES_PER_CONVERSATION = 500;

    private final Map<String, ConversationData> conversations = new LinkedHashMap<>();

    public synchronized void append(ProtocolMessage message, String senderAvatarId, String targetAvatarId) {
        if (message == null || message.sender == null || message.target == null || message.content == null) {
            return;
        }
        String key = conversationKey(message.sender, message.target);
        ConversationData data = conversations.computeIfAbsent(key,
                k -> new ConversationData(message.sender, message.target));
        data.messages.add(copy(message));
        if (data.messages.size() > MAX_MESSAGES_PER_CONVERSATION) {
            data.messages.remove(0);
        }
        data.lastMessage = message.content;
        data.lastActivity = message.timestamp > 0 ? message.timestamp : System.currentTimeMillis();
        data.avatarA = senderAvatarId;
        if (normalize(message.sender).equals(normalize(data.userA))) {
            data.avatarA = senderAvatarId;
            data.avatarB = targetAvatarId != null ? targetAvatarId : data.avatarB;
        } else {
            data.avatarB = senderAvatarId;
            data.avatarA = targetAvatarId != null ? targetAvatarId : data.avatarA;
        }
    }

    public synchronized List<ConversationSummary> getConversationsFor(String username) {
        if (username == null || username.isBlank()) return List.of();
        String userKey = normalize(username);
        List<ConversationSummary> result = new ArrayList<>();
        for (ConversationData data : conversations.values()) {
            String other = null;
            String avatar = null;
            if (normalize(data.userA).equals(userKey)) {
                other = data.userB;
                avatar = data.avatarB;
            } else if (normalize(data.userB).equals(userKey)) {
                other = data.userA;
                avatar = data.avatarA;
            }
            if (other != null) {
                result.add(new ConversationSummary(other, avatar, data.lastMessage, data.lastActivity));
            }
        }
        result.sort(Comparator.comparingLong((ConversationSummary c) -> c.lastActivity).reversed());
        return result;
    }

    public synchronized List<ProtocolMessage> getHistory(String username, String target) {
        if (username == null || target == null) return List.of();
        ConversationData data = conversations.get(conversationKey(username, target));
        if (data == null) return List.of();
        List<ProtocolMessage> result = new ArrayList<>(data.messages.size());
        for (ProtocolMessage message : data.messages) result.add(copy(message));
        result.sort(Comparator.comparingLong(m -> m.timestamp));
        return result;
    }

    public synchronized List<ConversationSummary> search(String username, String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        return getConversationsFor(username).stream()
                .filter(c -> q.isEmpty()
                        || safe(c.username).toLowerCase(Locale.ROOT).contains(q)
                        || safe(c.lastMessage).toLowerCase(Locale.ROOT).contains(q))
                .toList();
    }

    public synchronized void clear() {
        conversations.clear();
    }

    private static ProtocolMessage copy(ProtocolMessage source) {
        ProtocolMessage copy = new ProtocolMessage(source.type);
        copy.messageId = source.messageId;
        copy.sender = source.sender;
        copy.target = source.target;
        copy.content = source.content;
        copy.timestamp = source.timestamp;
        copy.avatarId = source.avatarId;
        copy.users = source.users;
        copy.errorCode = source.errorCode;
        copy.errorMessage = source.errorMessage;
        copy.conversations = source.conversations;
        copy.history = source.history;
        return copy;
    }

    private static String conversationKey(String a, String b) {
        String na = normalize(a);
        String nb = normalize(b);
        return na.compareTo(nb) < 0 ? na + "::" + nb : nb + "::" + na;
    }

    private static String normalize(String value) {
        return Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFC).toLowerCase(Locale.ROOT);
    }

    private static String safe(String value) { return value == null ? "" : value; }

    private static final class ConversationData {
        final String userA;
        final String userB;
        String avatarA;
        String avatarB;
        String lastMessage = "";
        long lastActivity;
        final List<ProtocolMessage> messages = new ArrayList<>();

        ConversationData(String userA, String userB) {
            this.userA = userA;
            this.userB = userB;
        }
    }
}
