package vn.edu.ut.udm08.shared.model;

/** Thông tin tóm tắt một cuộc trò chuyện riêng trong Sidebar. */
public class ConversationSummary {
    public String username;
    public String avatarId;
    public String lastMessage;
    public long lastActivity;

    public ConversationSummary() {}

    public ConversationSummary(String username, String avatarId, String lastMessage, long lastActivity) {
        this.username = username;
        this.avatarId = avatarId;
        this.lastMessage = lastMessage;
        this.lastActivity = lastActivity;
    }
}
