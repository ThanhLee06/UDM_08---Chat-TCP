package vn.edu.ut.udm08.client.controller;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.fxml.FXML;
import vn.edu.ut.udm08.client.network.ChatClient;
import vn.edu.ut.udm08.shared.model.ConversationSummary;
import vn.edu.ut.udm08.shared.model.MessageType;
import vn.edu.ut.udm08.shared.model.ProtocolMessage;
import vn.edu.ut.udm08.shared.model.UserProfile;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** Controller cho giao diện chat riêng và Sidebar hội thoại. */
public class ChatController {
    @FXML private ListView<ConversationSummary> conversationList;
    @FXML private TextField searchField;
    @FXML private Button newConversationButton;
    @FXML private Label chatPartnerName;
    @FXML private Label chatPartnerInitial;
    @FXML private StackPane chatPartnerAvatar;
    @FXML private ScrollPane messageScrollPane;
    @FXML private VBox messageContainer;
    @FXML private TextField messageInput;
    @FXML private Button sendButton;
    @FXML private VBox emptyStatePane;

    private final ObservableList<ConversationSummary> conversations = FXCollections.observableArrayList();
    private final List<ConversationSummary> allConversations = new ArrayList<>();
    private final ObservableList<UserProfile> onlineUsers = FXCollections.observableArrayList();

    private String currentUsername;
    private ConversationSummary selectedConversation;
    private ChatClient chatClient;

    private static final String[] AVATAR_COLORS = {
            "#0068ff", "#00c853", "#ff6d00", "#e91e63",
            "#9c27b0", "#00acc1", "#f4511e", "#5e35b1"
    };
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    public interface MessageSendListener {
        void onSendMessage(ProtocolMessage message);
    }

    private MessageSendListener sendListener;

    @FXML
    public void initialize() {
        conversationList.setItems(conversations);
        conversationList.setCellFactory(list -> new ConversationCell());
        conversationList.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) selectConversation(newVal);
        });

        searchField.textProperty().addListener((obs, oldValue, newValue) -> filterConversations(newValue));
        messageInput.setOnAction(e -> handleSend());
        sendButton.setDisable(true);
        messageInput.setDisable(true);
        emptyStatePane.setVisible(true);
    }

    public void setCurrentUsername(String username) { this.currentUsername = username; }
    public void setChatClient(ChatClient client) { this.chatClient = client; }
    public void setSendListener(MessageSendListener listener) { this.sendListener = listener; }

    /** ST-124/ST-125: khôi phục Sidebar và sắp xếp theo hoạt động mới nhất. */
    public void updateConversations(List<ConversationSummary> list) {
        Platform.runLater(() -> {
            allConversations.clear();
            if (list != null) allConversations.addAll(list);
            sortConversations();
            filterConversations(searchField == null ? "" : searchField.getText());
        });
    }

    /** Danh sách người online chỉ dùng để bắt đầu cuộc trò chuyện mới. */
    public void updateOnlineUsers(List<UserProfile> users) {
        Platform.runLater(() -> {
            onlineUsers.clear();
            if (users != null) {
                users.stream()
                        .filter(u -> u != null && u.username != null
                                && !u.username.equalsIgnoreCase(currentUsername))
                        .forEach(onlineUsers::add);
            }
        });
    }

    /** ST-127: mở hội thoại riêng với một người đang online. */
    @FXML
    private void handleNewConversation() {
        if (onlineUsers.isEmpty()) {
            showInfo("Chưa có người dùng online để bắt đầu cuộc trò chuyện mới.");
            return;
        }
        List<String> names = onlineUsers.stream().map(u -> u.username).toList();
        ChoiceDialog<String> dialog = new ChoiceDialog<>(names.get(0), names);
        dialog.setTitle("Cuộc trò chuyện mới");
        dialog.setHeaderText("Chọn người bạn muốn nhắn tin riêng");
        dialog.setContentText("Người dùng:");
        dialog.showAndWait().ifPresent(name -> onlineUsers.stream()
                .filter(u -> u.username.equals(name))
                .findFirst()
                .ifPresent(this::startConversation));
    }

    private void startConversation(UserProfile user) {
        ConversationSummary summary = findConversation(user.username);
        if (summary == null) {
            summary = new ConversationSummary(user.username, user.avatarId, "Chưa có tin nhắn", System.currentTimeMillis());
            allConversations.add(summary);
            sortConversations();
            filterConversations(searchField.getText());
        }
        selectConversation(summary);
        conversationList.getSelectionModel().select(summary);
    }

    /** ST-126: chọn hội thoại thì yêu cầu Server tải lịch sử. */
    private void selectConversation(ConversationSummary conversation) {
        selectedConversation = conversation;
        chatPartnerName.setText(conversation.username);
        chatPartnerInitial.setText(initialOf(conversation.username));
        chatPartnerAvatar.setStyle("-fx-background-color: " + avatarColorFor(conversation.username) + ";");
        messageContainer.getChildren().clear();
        sendButton.setDisable(false);
        messageInput.setDisable(false);
        emptyStatePane.setVisible(false);
        messageInput.requestFocus();

        if (chatClient != null) {
            try {
                chatClient.requestConversationHistory(conversation.username);
            } catch (Exception e) {
                showInfo("Không thể tải lịch sử hội thoại: " + e.getMessage());
            }
        }
    }

    /** ST-126: nhận lịch sử từ Server và dựng lại khung chat. */
    public void receiveConversationHistory(String target, List<ProtocolMessage> history) {
        Platform.runLater(() -> {
            if (selectedConversation == null || target == null
                    || !target.equalsIgnoreCase(selectedConversation.username)) return;
            messageContainer.getChildren().clear();
            if (history != null) {
                history.stream()
                        .sorted(Comparator.comparingLong(m -> m.timestamp))
                        .forEach(m -> addMessageBubble(m.sender, m.content, m.timestamp,
                                m.sender != null && m.sender.equalsIgnoreCase(currentUsername)));
            }
        });
    }

    /** Tin nhắn đến làm Sidebar cập nhật ngay cả khi đang ở hội thoại khác. */
    public void receiveMessage(ProtocolMessage message) {
        Platform.runLater(() -> {
            if (message == null || message.sender == null || message.target == null) return;
            String other = message.sender.equalsIgnoreCase(currentUsername) ? message.target : message.sender;
            upsertConversation(other, null, message.content, message.timestamp);

            if (selectedConversation != null && other.equalsIgnoreCase(selectedConversation.username)) {
                // Tin do chính mình gửi đã được hiển thị cục bộ; tránh thêm trùng.
                boolean mine = message.sender.equalsIgnoreCase(currentUsername);
                if (!mine) addMessageBubble(message.sender, message.content, message.timestamp, false);
            }
        });
    }

    /** ST-125: đồng bộ tin cuối cùng + thứ tự hoạt động. */
    private void upsertConversation(String username, String avatarId, String lastMessage, long timestamp) {
        ConversationSummary existing = findConversation(username);
        if (existing == null) {
            allConversations.add(new ConversationSummary(username, avatarId, lastMessage, timestamp));
        } else {
            if (avatarId != null && !avatarId.isBlank()) existing.avatarId = avatarId;
            existing.lastMessage = lastMessage;
            existing.lastActivity = timestamp > 0 ? timestamp : System.currentTimeMillis();
        }
        sortConversations();
        filterConversations(searchField == null ? "" : searchField.getText());
    }

    private void sortConversations() {
        allConversations.sort(Comparator.comparingLong((ConversationSummary c) -> c.lastActivity).reversed());
    }

    /** ST-128: tìm kiếm trong các hội thoại đã tồn tại. */
    private void filterConversations(String query) {
        String q = query == null ? "" : query.trim().toLowerCase();
        conversations.setAll(allConversations.stream()
                .filter(c -> q.isEmpty()
                        || safe(c.username).toLowerCase().contains(q)
                        || safe(c.lastMessage).toLowerCase().contains(q))
                .sorted(Comparator.comparingLong((ConversationSummary c) -> c.lastActivity).reversed())
                .toList());
    }

    private ConversationSummary findConversation(String username) {
        return allConversations.stream()
                .filter(c -> c.username != null && c.username.equalsIgnoreCase(username))
                .findFirst().orElse(null);
    }

    @FXML
    private void handleSend() {
        String content = messageInput.getText().trim();
        if (content.isEmpty() || selectedConversation == null) return;

        ProtocolMessage message = new ProtocolMessage(MessageType.CHAT);
        message.messageId = UUID.randomUUID().toString();
        message.sender = currentUsername;
        message.target = selectedConversation.username;
        message.content = content;
        message.timestamp = System.currentTimeMillis();

        addMessageBubble(currentUsername, content, message.timestamp, true);
        upsertConversation(selectedConversation.username, selectedConversation.avatarId, content, message.timestamp);
        messageInput.clear();

        if (sendListener != null) sendListener.onSendMessage(message);
    }

    private void addMessageBubble(String sender, String content, long timestamp, boolean isMine) {
        Label bubble = new Label(content == null ? "" : content);
        bubble.getStyleClass().add(isMine ? "message-bubble-sent" : "message-bubble-received");
        bubble.setWrapText(true);
        bubble.setMaxWidth(400);

        String timeText = Instant.ofEpochMilli(timestamp > 0 ? timestamp : System.currentTimeMillis())
                .atZone(ZoneId.systemDefault()).format(TIME_FORMAT);
        Label timeLabel = new Label(timeText);
        timeLabel.getStyleClass().add("message-timestamp");

        VBox column = new VBox(3);
        column.setAlignment(isMine ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
        HBox row = new HBox(8);
        row.setAlignment(isMine ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);

        if (isMine) {
            column.getChildren().addAll(bubble, timeLabel);
            row.getChildren().add(column);
        } else {
            Label initial = new Label(initialOf(sender));
            initial.getStyleClass().add("avatar-text-small");
            StackPane avatar = new StackPane(initial);
            avatar.getStyleClass().add("avatar-circle-small");
            avatar.setStyle("-fx-background-color: " + avatarColorFor(sender) + ";");
            Label nameLabel = new Label(sender);
            nameLabel.getStyleClass().add("message-sender-name");
            column.getChildren().addAll(nameLabel, bubble, timeLabel);
            row.getChildren().addAll(avatar, column);
        }
        messageContainer.getChildren().add(row);
        messageScrollPane.layout();
        messageScrollPane.setVvalue(1.0);
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Chat TCP");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private static String safe(String s) { return s == null ? "" : s; }
    private static String initialOf(String s) { return s == null || s.isBlank() ? "?" : s.substring(0, 1).toUpperCase(); }
    private static String avatarColorFor(String username) {
        int index = Math.floorMod(username == null ? 0 : username.hashCode(), AVATAR_COLORS.length);
        return AVATAR_COLORS[index];
    }

    private static class ConversationCell extends ListCell<ConversationSummary> {
        @Override protected void updateItem(ConversationSummary item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null); setGraphic(null); return;
            }
            Label initial = new Label(initialOf(item.username));
            initial.getStyleClass().add("avatar-text-small");
            StackPane avatar = new StackPane(initial);
            avatar.getStyleClass().add("avatar-circle-small");
            avatar.setStyle("-fx-background-color: " + avatarColorFor(item.username) + ";");

            Label name = new Label(item.username);
            name.getStyleClass().add("cell-name");
            Label preview = new Label(item.lastMessage == null ? "" : item.lastMessage);
            preview.getStyleClass().add("conversation-preview");
            preview.setMaxWidth(155);
            preview.setEllipsisString("…");

            VBox text = new VBox(2, name, preview);
            HBox box = new HBox(10, avatar, text);
            box.setAlignment(Pos.CENTER_LEFT);
            setGraphic(box); setText(null);
        }
    }
}
