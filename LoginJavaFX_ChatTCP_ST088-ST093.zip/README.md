# LoginJavaFX + Chat TCP

Project JavaFX + TCP socket mẫu, tiếp tục từ màn hình Login.

## Chạy Server
Trong IntelliJ:
1. Mở `ChatServer.java`
2. Run `ChatServer.main()`
3. Server chạy port `5555`.

## Chạy Client
1. Run `Launcher.java`
2. Login với:
   - Username: tên bất kỳ
   - Host: `127.0.0.1`
   - Port: `5555`

Có thể mở nhiều Client để test chat.

## Đã làm ST-088 → ST-093
- ST-088: Tab/mode Phòng chung, Tin nhắn riêng, Nhóm.
- ST-089: Danh sách hội thoại đã mở.
- ST-090: Tin nhắn cuối cùng + thời gian.
- ST-091: Hội thoại tự sắp xếp theo tin nhắn mới nhất.
- ST-092: Open width options: Narrow / Normal / Wide.
- ST-093: Tách `base.css`, `sidebar.css`, `chat.css`.

## Lưu ý
Đây là bộ khung Chat TCP mới vì project bạn gửi hiện mới có phần Login. Có thể ghép thêm database, avatar selector, nhóm thật và lưu lịch sử sau.
