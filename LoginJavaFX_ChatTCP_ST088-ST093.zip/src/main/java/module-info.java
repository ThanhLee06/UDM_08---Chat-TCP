module com.example.loginjavafx {
    requires javafx.controls;
    requires javafx.fxml;

    exports com.example.loginjavafx;
    opens com.example.loginjavafx to javafx.fxml;
}
