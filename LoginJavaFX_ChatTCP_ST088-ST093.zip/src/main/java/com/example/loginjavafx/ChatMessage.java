package com.example.loginjavafx;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public record ChatMessage(
        String conversationId,
        String conversationName,
        String sender,
        String content,
        LocalDateTime time,
        boolean privateMessage
) {
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    public String displayTime() {
        return time.format(FORMAT);
    }
}
