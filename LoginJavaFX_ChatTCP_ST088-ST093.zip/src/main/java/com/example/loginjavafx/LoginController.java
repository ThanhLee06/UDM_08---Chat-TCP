package com.example.loginjavafx;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private TextField hostField;
    @FXML private TextField portField;
    @FXML private Label statusLabel;

    @FXML
    private void handleLogin() {
        String username = usernameField.getText() == null ? "" : usernameField.getText().trim();
        String host = hostField.getText() == null ? "" : hostField.getText().trim();
        String portText = portField.getText() == null ? "" : portField.getText().trim();

        // Client-side validation: server still remains the final authority.
        if (username.isEmpty()) {
            showError("Tên người dùng không được để trống.");
            usernameField.requestFocus();
            return;
        }
        if (username.length() > 30 || !username.matches("[\\p{L}\\p{N}_ .-]+")) {
            showError("Tên dài tối đa 30 ký tự và chỉ dùng chữ, số, khoảng trắng, _, -, .");
            usernameField.requestFocus();
            return;
        }
        if (host.isEmpty()) {
            showError("Vui lòng nhập Host.");
            hostField.requestFocus();
            return;
        }

        int port;
        try {
            port = Integer.parseInt(portText);
            if (port < 1 || port > 65535) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            showError("Port phải là số từ 1 đến 65535.");
            portField.requestFocus();
            return;
        }

        try {
            ChatClient client = new ChatClient(host, port);
            client.connect(username);

            FXMLLoader loader = new FXMLLoader(
                    HelloApplication.class.getResource("/fxml/ChatView.fxml")
            );
            Scene scene = new Scene(loader.load(), 1100, 700);

            ChatController controller = loader.getController();
            controller.init(client, username);

            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setTitle("TCP Chat - " + username);
            stage.setScene(scene);
            stage.setMinWidth(900);
            stage.setMinHeight(600);
        } catch (Exception e) {
            showError("Không kết nối được Server: " + e.getMessage());
        }
    }

    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().removeAll("success");
        if (!statusLabel.getStyleClass().contains("error")) statusLabel.getStyleClass().add("error");
    }
}
