package com.example.loginjavafx;

public class Launcher {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
