package com.example.loginjavafx;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ChatServer {
    private static final int PORT = 5555;
    private static final Set<ClientHandler> clients = ConcurrentHashMap.newKeySet();
    private static final Set<String> usernames = ConcurrentHashMap.newKeySet();

    public static void main(String[] args) throws IOException {
        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("TCP Chat Server đang chạy tại port " + PORT);
            while (true) {
                Socket socket = server.accept();
                ClientHandler client = new ClientHandler(socket);
                clients.add(client);
                new Thread(client, "client-" + socket.getPort()).start();
            }
        }
    }

    private static void broadcast(String line) {
        clients.forEach(c -> c.send(line));
    }

    private static void sendToUser(String username, String line) {
        clients.stream()
                .filter(c -> username.equalsIgnoreCase(c.username))
                .forEach(c -> c.send(line));
    }

    private static class ClientHandler implements Runnable {
        private final Socket socket;
        private BufferedReader reader;
        private BufferedWriter writer;
        private String username;

        ClientHandler(Socket socket) {
            this.socket = socket;
        }

        void send(String line) {
            try {
                writer.write(line);
                writer.newLine();
                writer.flush();
            } catch (IOException ignored) {}
        }

        @Override
        public void run() {
            try {
                reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));

                String line;
                while ((line = reader.readLine()) != null) {
                    handle(line);
                }
            } catch (IOException ignored) {
            } finally {
                clients.remove(this);
                if (username != null) usernames.remove(username);
                if (username != null) broadcast("SYSTEM|👋 " + username + " đã rời phòng.");
                try { socket.close(); } catch (IOException ignored) {}
            }
        }

        private void handle(String line) {
            String[] p = line.split("\\|", 4);
            if (p.length == 0) return;

            switch (p[0]) {
                case "LOGIN" -> {
                    if (p.length < 2 || p[1].isBlank()) {
                        send("ERROR|Tên đăng nhập không hợp lệ.");
                        return;
                    }
                    if (!usernames.add(p[1])) {
                        send("ERROR|Tên người dùng đã tồn tại.");
                        return;
                    }
                    username = p[1];
                    send("LOGIN_OK|" + username);
                    broadcast("SYSTEM|👋 " + username + " đã tham gia phòng chung.");
                }
                case "PUBLIC" -> {
                    if (username != null && p.length >= 2)
                        broadcast("PUBLIC|" + username + "|" + p[1]);
                }
                case "PRIVATE" -> {
                    if (username != null && p.length >= 3) {
                        String target = p[1];
                        String msg = p[2];
                        sendToUser(target, "PRIVATE|" + username + "|" + msg);
                        send("PRIVATE|" + username + "|" + msg);
                    }
                }
                case "GROUP" -> {
                    if (username != null && p.length >= 3)
                        broadcast("GROUP|" + p[1] + "|" + username + "|" + p[2]);
                }
                default -> send("ERROR|Lệnh không được hỗ trợ.");
            }
        }
    }
}
