package com.example.loginjavafx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.LocalDateTime;

public class Conversation {
    private final String id;
    private final String name;
    private final boolean privateChat;
    private final ObservableList<ChatMessage> messages = FXCollections.observableArrayList();
    private String lastMessage = "";
    private LocalDateTime lastTime = LocalDateTime.MIN;

    public Conversation(String id, String name, boolean privateChat) {
        this.id = id;
        this.name = name;
        this.privateChat = privateChat;
    }

    public void addMessage(ChatMessage message) {
        messages.add(message);
        if (message.time().isAfter(lastTime)) {
            lastTime = message.time();
            lastMessage = message.content();
        }
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public boolean isPrivateChat() { return privateChat; }
    public ObservableList<ChatMessage> getMessages() { return messages; }
    public String getLastMessage() { return lastMessage; }
    public LocalDateTime getLastTime() { return lastTime; }
    public String getTimeText() { return lastTime.equals(LocalDateTime.MIN) ? "" :
            lastTime.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")); }
}
