package com.example.loginjavafx;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.function.Consumer;

public class ChatClient {
    private final String host;
    private final int port;
    private Socket socket;
    private BufferedReader reader;
    private BufferedWriter writer;
    private Thread listener;
    private Consumer<String> messageHandler = s -> {};

    public ChatClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public void connect(String username) throws IOException {
        socket = new Socket(host, port);
        reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));

        send("LOGIN|" + username);

        listener = new Thread(() -> {
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    messageHandler.accept(line);
                }
            } catch (IOException ignored) {
                messageHandler.accept("SYSTEM|Kết nối Server đã đóng.");
            }
        }, "tcp-chat-reader");
        listener.setDaemon(true);
        listener.start();
    }

    public void setMessageHandler(Consumer<String> handler) {
        this.messageHandler = handler == null ? s -> {} : handler;
    }

    public synchronized void send(String message) throws IOException {
        writer.write(message);
        writer.newLine();
        writer.flush();
    }

    public void sendPublic(String content) throws IOException {
        send("PUBLIC|" + content);
    }

    public void sendPrivate(String username, String content) throws IOException {
        send("PRIVATE|" + username + "|" + content);
    }

    public void sendGroup(String group, String content) throws IOException {
        send("GROUP|" + group + "|" + content);
    }

    public void close() {
        try { if (socket != null) socket.close(); } catch (IOException ignored) {}
    }
}
