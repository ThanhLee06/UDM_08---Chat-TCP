package com.example.loginjavafx;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class ChatController {
    @FXML private ListView<Conversation> conversationList;
    @FXML private Label conversationTitle;
    @FXML private Label conversationType;
    @FXML private VBox messageBox;
    @FXML private TextField messageField;
    @FXML private TextField privateTargetField;
    @FXML private ComboBox<String> modeCombo;
    @FXML private Label currentUserLabel;
    @FXML private BorderPane root;

    private ChatClient client;
    private String username;
    private final Map<String, Conversation> conversations = new HashMap<>();
    private Conversation currentConversation;

    public void init(ChatClient client, String username) {
        this.client = client;
        this.username = username;
        currentUserLabel.setText(username);

        Conversation general = new Conversation("public", "Phòng chung", false);
        conversations.put(general.getId(), general);
        conversationList.setItems(FXCollections.observableArrayList(general));
        conversationList.getSelectionModel().select(general);
        currentConversation = general;
        refreshMessages();

        client.setMessageHandler(this::handleIncoming);
    }

    @FXML
    private void initialize() {
        modeCombo.setItems(FXCollections.observableArrayList("Phòng chung", "Tin nhắn riêng", "Nhóm"));
        modeCombo.getSelectionModel().selectFirst();

        conversationList.setCellFactory(list -> new ListCell<>() {
            @Override
            protected void updateItem(Conversation c, boolean empty) {
                super.updateItem(c, empty);
                if (empty || c == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    VBox box = new VBox(2);
                    Label name = new Label((c.isPrivateChat() ? "● " : "● ") + c.getName());
                    name.getStyleClass().add("conversation-name");
                    Label last = new Label(c.getLastMessage().isBlank() ? "Chưa có tin nhắn" : c.getLastMessage());
                    last.getStyleClass().add("conversation-last");
                    Label time = new Label(c.getTimeText());
                    time.getStyleClass().add("conversation-time");
                    HBox bottom = new HBox(last, new Region(), time);
                    HBox.setHgrow(bottom.getChildren().get(1), Priority.ALWAYS);
                    box.getChildren().addAll(name, bottom);
                    setGraphic(box);
                }
            }
        });

        conversationList.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> {
            if (selected != null) {
                currentConversation = selected;
                conversationTitle.setText(selected.getName());
                conversationType.setText(selected.isPrivateChat() ? "Tin nhắn riêng" : "Phòng / nhóm");
                refreshMessages();
            }
        });

        conversationList.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.PRIMARY && e.getClickCount() == 2) {
                Conversation c = conversationList.getSelectionModel().getSelectedItem();
                if (c != null) openConversation(c);
            }
        });
    }

    @FXML
    private void sendMessage() {
        String text = messageField.getText().trim();
        if (text.isEmpty() || client == null) return;

        try {
            String mode = modeCombo.getValue();
            if ("Tin nhắn riêng".equals(mode)) {
                String target = privateTargetField.getText().trim();
                if (target.isEmpty()) {
                    showAlert("Nhập tên người nhận trước.");
                    return;
                }
                openPrivateConversation(target);
                client.sendPrivate(target, text);
            } else if ("Nhóm".equals(mode)) {
                String group = privateTargetField.getText().trim();
                if (group.isEmpty()) {
                    showAlert("Nhập tên nhóm trước.");
                    return;
                }
                openGroupConversation(group);
                client.sendGroup(group, text);
            } else {
                openConversation(conversations.get("public"));
                client.sendPublic(text);
            }
            messageField.clear();
        } catch (Exception e) {
            showAlert("Gửi tin nhắn thất bại: " + e.getMessage());
        }
    }

    @FXML
    private void newPrivateConversation() {
        String target = privateTargetField.getText().trim();
        if (!target.isEmpty()) openPrivateConversation(target);
    }

    private void openPrivateConversation(String target) {
        String id = "private:" + target.toLowerCase(Locale.ROOT);
        Conversation c = conversations.computeIfAbsent(id, k -> new Conversation(id, target, true));
        refreshConversationList(c);
        openConversation(c);
    }

    private void openGroupConversation(String group) {
        String id = "group:" + group.toLowerCase(Locale.ROOT);
        Conversation c = conversations.computeIfAbsent(id, k -> new Conversation(id, group, false));
        refreshConversationList(c);
        openConversation(c);
    }

    private void openConversation(Conversation c) {
        if (c == null) return;
        currentConversation = c;
        conversationList.getSelectionModel().select(c);
        conversationTitle.setText(c.getName());
        conversationType.setText(c.isPrivateChat() ? "Tin nhắn riêng" : "Phòng / nhóm");
        refreshMessages();
    }

    private void refreshConversationList(Conversation selected) {
        List<Conversation> sorted = conversations.values().stream()
                .sorted(Comparator.comparing(Conversation::getLastTime).reversed())
                .collect(Collectors.toList());
        conversationList.setItems(FXCollections.observableArrayList(sorted));
        if (selected != null) conversationList.getSelectionModel().select(selected);
    }

    private void handleIncoming(String line) {
        Platform.runLater(() -> {
            String[] p = line.split("\\|", 4);
            if (p.length == 0) return;

            try {
                switch (p[0]) {
                    case "LOGIN_OK" -> {}
                    case "SYSTEM" -> addSystemMessage(p.length > 1 ? p[1] : "");
                    case "PUBLIC" -> {
                        if (p.length >= 3) addMessage("public", "Phòng chung", p[1], p[2], false);
                    }
                    case "PRIVATE" -> {
                        if (p.length >= 3) {
                            String other = p[1].equals(username) ? p[1] : p[1];
                            addMessage("private:" + other.toLowerCase(Locale.ROOT), other, p[1], p[2], true);
                        }
                    }
                    case "GROUP" -> {
                        if (p.length >= 4)
                            addMessage("group:" + p[1].toLowerCase(Locale.ROOT), p[1], p[2], p[3], false);
                    }
                    case "ERROR" -> showAlert(p.length > 1 ? p[1] : "Server báo lỗi.");
                }
            } catch (Exception ignored) {}
        });
    }

    private void addMessage(String id, String name, String sender, String text, boolean privateChat) {
        Conversation c = conversations.computeIfAbsent(id, k -> new Conversation(id, name, privateChat));
        c.addMessage(new ChatMessage(id, name, sender, text, LocalDateTime.now(), privateChat));
        refreshConversationList(currentConversation == c ? c : null);
        if (currentConversation == c) refreshMessages();
    }

    private void addSystemMessage(String text) {
        Conversation c = conversations.get("public");
        c.addMessage(new ChatMessage("public", "Phòng chung", "SYSTEM", text, LocalDateTime.now(), false));
        if (currentConversation == c) refreshMessages();
        refreshConversationList(c);
    }

    private void refreshMessages() {
        messageBox.getChildren().clear();
        if (currentConversation == null) return;

        for (ChatMessage msg : currentConversation.getMessages()) {
            VBox bubble = new VBox(3);
            Label sender = new Label(msg.sender());
            sender.getStyleClass().add("message-sender");
            Label content = new Label(msg.content());
            content.setWrapText(true);
            Label time = new Label(msg.displayTime());
            time.getStyleClass().add("message-time");

            bubble.getChildren().addAll(sender, content, time);
            bubble.getStyleClass().add(msg.sender().equals(username) ? "message-own" : "message-other");
            bubble.setMaxWidth(560);

            HBox row = new HBox(bubble);
            row.setAlignment(msg.sender().equals(username) ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
            messageBox.getChildren().add(row);
        }
    }

    @FXML
    private void applyWidthNarrow() {
        setChatWidth(360);
    }

    @FXML
    private void applyWidthNormal() {
        setChatWidth(560);
    }

    @FXML
    private void applyWidthWide() {
        setChatWidth(760);
    }

    private void setChatWidth(double width) {
        for (var node : messageBox.getChildren()) {
            if (node instanceof HBox row && !row.getChildren().isEmpty()) {
                row.getChildren().get(0).setStyle("-fx-max-width: " + width + "px;");
            }
        }
    }

    @FXML
    private void logout() {
        if (client != null) client.close();
        Stage stage = (Stage) root.getScene().getWindow();
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                    HelloApplication.class.getResource("/fxml/LoginView.fxml"));
            stage.setScene(new javafx.scene.Scene(loader.load(), 560, 650));
            stage.setTitle("TCP Chat - Login");
        } catch (Exception e) {
            stage.close();
        }
    }

    private void showAlert(String text) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("TCP Chat");
        alert.setHeaderText(null);
        alert.setContentText(text);
        alert.showAndWait();
    }
}
